// alertService.js
// Derives extreme-weather advisories from forecast data (simple rule-based
// disaster-management logic, since a live govt alert feed needs a paid key).

function buildAlerts({ place, current, daily }) {
  const alerts = [];

  if (current.temperature >= 40) {
    alerts.push({
      severity: "severe",
      type: "Heat Wave",
      message: `Extreme heat in ${place.name}: ${current.temperature}°C. Avoid outdoor exposure between 12–4 PM, stay hydrated.`,
    });
  }
  if (current.temperature <= 4) {
    alerts.push({
      severity: "severe",
      type: "Cold Wave",
      message: `Very low temperature in ${place.name}: ${current.temperature}°C. Risk of cold-related illness, protect crops and livestock.`,
    });
  }
  if (current.windSpeed >= 40) {
    alerts.push({
      severity: "moderate",
      type: "High Wind",
      message: `Strong winds in ${place.name}: ${current.windSpeed} km/h. Secure loose objects, avoid coastal/open areas.`,
    });
  }
  if ([65, 82, 95, 96, 99].includes(current.weatherCode)) {
    alerts.push({
      severity: "severe",
      type: "Heavy Rain / Storm",
      message: `${current.description} reported in ${place.name}. Risk of flooding and waterlogging, avoid low-lying areas.`,
    });
  }

  daily.forEach((d) => {
    if (d.precipitationSum >= 60) {
      alerts.push({
        severity: "severe",
        type: "Heavy Rainfall Forecast",
        message: `Heavy rainfall expected on ${d.date} in ${place.name} (${d.precipitationSum} mm). Farmers should delay spraying/harvest.`,
      });
    }
    if (d.tempMax >= 42) {
      alerts.push({
        severity: "severe",
        type: "Heat Wave Forecast",
        message: `Very high temperature expected on ${d.date} in ${place.name} (${d.tempMax}°C).`,
      });
    }
    if (d.windSpeedMax >= 50) {
      alerts.push({
        severity: "moderate",
        type: "Storm Wind Forecast",
        message: `High winds expected on ${d.date} in ${place.name} (${d.windSpeedMax} km/h).`,
      });
    }
  });

  if (alerts.length === 0) {
    alerts.push({
      severity: "none",
      type: "No Active Alerts",
      message: `No extreme weather advisories for ${place.name} at this time.`,
    });
  }

  return alerts;
}

module.exports = { buildAlerts };
