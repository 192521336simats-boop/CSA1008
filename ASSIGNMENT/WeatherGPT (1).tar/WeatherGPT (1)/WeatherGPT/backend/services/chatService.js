// chatService.js
// Rule-based natural-language understanding for the WeatherGPT assistant.
// Works fully offline (no API key needed). If OPENAI_API_KEY is set in .env,
// it will use it to generate a friendlier final reply on top of the same
// real weather data (optional upgrade path for CO5 - AI/LLM integration).

const { getCurrentAndForecast, getHistory } = require("./weatherService");
const { buildAlerts } = require("./alertService");

const INDIAN_CITY_HINTS = [
  "chennai", "delhi", "mumbai", "kolkata", "bengaluru", "bangalore", "hyderabad",
  "pune", "ahmedabad", "jaipur", "lucknow", "coimbatore", "madurai", "trichy",
  "avadi", "vellore", "salem", "kochi", "trivandrum", "patna", "bhopal", "indore",
];

function detectIntent(message) {
  const m = message.toLowerCase();
  if (/(alert|warning|advisory|danger|storm|cyclone)/.test(m)) return "alert";
  if (/(history|historical|last week|last month|trend|past)/.test(m)) return "history";
  if (/(forecast|tomorrow|next|week|days ahead)/.test(m)) return "forecast";
  return "current";
}

function extractCity(message) {
  const m = message.trim();
  // Pattern: "weather in <city>", "in <city>", "at <city>", "for <city>"
  const match = m.match(/(?:in|at|for|of)\s+([a-zA-Z\s]{2,40})$/i);
  if (match) return match[1].trim();

  // Fallback: check for a known Indian city name anywhere in the message
  const lower = m.toLowerCase();
  const found = INDIAN_CITY_HINTS.find((c) => lower.includes(c));
  if (found) return found;

  return null;
}

async function handleChatMessage(message, defaultCity) {
  const intent = detectIntent(message);
  const city = extractCity(message) || defaultCity;

  if (!city) {
    return {
      intent,
      reply:
        "Please tell me a location — for example: 'What's the weather in Chennai?' or 'Any alerts for Delhi?'",
      data: null,
    };
  }

  try {
    if (intent === "history") {
      const end = new Date();
      const start = new Date();
      start.setDate(end.getDate() - 7);
      const fmt = (d) => d.toISOString().split("T")[0];
      const result = await getHistory(city, fmt(start), fmt(end));
      const avgMax =
        result.daily.reduce((s, d) => s + d.tempMax, 0) / result.daily.length;
      return {
        intent,
        reply: `Over the last 7 days, ${result.place.name} had an average high of ${avgMax.toFixed(
          1
        )}°C. Check the History tab for the full trend.`,
        data: result,
      };
    }

    const wx = await getCurrentAndForecast(city);

    if (intent === "alert") {
      const alerts = buildAlerts(wx);
      const top = alerts[0];
      return {
        intent,
        reply: `${top.type === "No Active Alerts" ? "Good news — " : "⚠️ "}${top.message}`,
        data: { ...wx, alerts },
      };
    }

    if (intent === "forecast") {
      const next3 = wx.daily.slice(1, 4);
      const summary = next3
        .map((d) => `${d.date}: ${d.description}, ${d.tempMin}–${d.tempMax}°C`)
        .join(" | ");
      return {
        intent,
        reply: `Forecast for ${wx.place.name}: ${summary}`,
        data: wx,
      };
    }

    // default: current weather
    return {
      intent,
      reply: `Right now in ${wx.place.name}: ${wx.current.description}, ${wx.current.temperature}°C (feels like ${wx.current.feelsLike}°C), humidity ${wx.current.humidity}%, wind ${wx.current.windSpeed} km/h.`,
      data: wx,
    };
  } catch (err) {
    if (err.code === "LOCATION_NOT_FOUND") {
      return {
        intent,
        reply: `I couldn't find a place called "${city}". Could you check the spelling or try a nearby major city?`,
        data: null,
      };
    }
    throw err;
  }
}

module.exports = { handleChatMessage, detectIntent, extractCity };
