const express = require("express");
const router = express.Router();
const { getCurrentAndForecast, getHistory, geocodeCity } = require("../services/weatherService");
const { buildAlerts } = require("../services/alertService");
const { handleChatMessage } = require("../services/chatService");

// GET /api/weather?city=Chennai
router.get("/weather", async (req, res) => {
  try {
    const city = req.query.city;
    if (!city) return res.status(400).json({ error: "city query param is required" });
    const result = await getCurrentAndForecast(city);
    res.json(result);
  } catch (err) {
    res.status(err.code === "LOCATION_NOT_FOUND" ? 404 : 500).json({ error: err.message });
  }
});

// GET /api/alerts?city=Chennai
router.get("/alerts", async (req, res) => {
  try {
    const city = req.query.city;
    if (!city) return res.status(400).json({ error: "city query param is required" });
    const wx = await getCurrentAndForecast(city);
    const alerts = buildAlerts(wx);
    res.json({ place: wx.place, alerts });
  } catch (err) {
    res.status(err.code === "LOCATION_NOT_FOUND" ? 404 : 500).json({ error: err.message });
  }
});

// GET /api/history?city=Chennai&start=2025-01-01&end=2025-01-07
router.get("/history", async (req, res) => {
  try {
    const { city, start, end } = req.query;
    if (!city || !start || !end)
      return res.status(400).json({ error: "city, start and end query params are required" });
    const result = await getHistory(city, start, end);
    res.json(result);
  } catch (err) {
    res.status(err.code === "LOCATION_NOT_FOUND" ? 404 : 500).json({ error: err.message });
  }
});

// GET /api/geocode?city=Chennai
router.get("/geocode", async (req, res) => {
  try {
    const city = req.query.city;
    if (!city) return res.status(400).json({ error: "city query param is required" });
    const place = await geocodeCity(city);
    res.json(place);
  } catch (err) {
    res.status(err.code === "LOCATION_NOT_FOUND" ? 404 : 500).json({ error: err.message });
  }
});

// POST /api/chat  { message: "weather in Chennai", defaultCity: "Chennai" }
router.post("/chat", async (req, res) => {
  try {
    const { message, defaultCity } = req.body;
    if (!message) return res.status(400).json({ error: "message is required" });
    const result = await handleChatMessage(message, defaultCity);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
