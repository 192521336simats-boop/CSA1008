require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const weatherRoutes = require("./routes/weather");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// API routes
app.use("/api", weatherRoutes);

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", service: "WeatherGPT backend", time: new Date().toISOString() });
});

// Serve the frontend (so you can run ONE server for everything)
const frontendPath = path.join(__dirname, "..", "frontend");
app.use(express.static(frontendPath));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api")) return next();
  res.sendFile(path.join(frontendPath, "index.html"));
});

app.listen(PORT, () => {
  console.log(`\n🌤  WeatherGPT backend running at http://localhost:${PORT}`);
  console.log(`   Open http://localhost:${PORT} in your browser to use the dashboard.\n`);
});
