# WeatherGPT — Conversational AI for Weather Forecasting, Alerts & Climate Info

Full-stack implementation of the WeatherGPT problem statement (IMD / MoES, Disaster Management theme).

## What's inside
- **backend/** — Node.js + Express REST API. Uses the free Open-Meteo API (no key required) for
  geocoding, current weather, 7-day forecasts and historical weather archives. Includes a
  rule-based conversational NLU engine (`services/chatService.js`) that understands queries like
  *"weather in Chennai"*, *"forecast for Delhi"*, *"any alerts for Mumbai"*, *"history of Pune"*.
- **frontend/** — Plain HTML/CSS/JS dashboard (no build step needed): chat assistant, live weather
  dashboard, alerts panel, and a historical trend chart (Chart.js). Supports English / Hindi / Tamil.

## How to run (VS Code)

1. Open the `WeatherGPT` folder in VS Code.
2. Open a terminal in VS Code: `Terminal > New Terminal`.
3. Install backend dependencies and start the server:

   ```bash
   cd backend
   npm install
   npm start
   ```

4. Open your browser at **http://localhost:5000** — the backend also serves the frontend, so
   you only need ONE server running. That's it — full frontend + backend working together.

   (Requires Node.js 18+ since it uses the built-in `fetch`. Check with `node -v`.)

## API Endpoints (backend)
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/weather?city=Chennai` | Current + 7-day forecast |
| GET | `/api/alerts?city=Chennai` | Extreme weather advisories |
| GET | `/api/history?city=Chennai&start=YYYY-MM-DD&end=YYYY-MM-DD` | Historical daily weather |
| GET | `/api/geocode?city=Chennai` | Resolve a place name to lat/lon |
| POST | `/api/chat` | Body: `{ "message": "weather in Chennai" }` — conversational endpoint |

## Notes for your assignment writeup
- **Requirements & MoSCoW**: do this in Google Sheets as instructed — this code is the "Development" step.
- **Architecture**: Frontend (HTML/CSS/JS dashboard) ↔ Backend (Express REST API) ↔ Open-Meteo
  (external weather data provider). Draw this as a 3-tier diagram in Umbrello.
- **AI/LLM angle (CO5)**: the chat assistant currently uses a lightweight rule-based NLU engine
  (intent detection + entity/city extraction) so it works with zero cost and zero API keys — good
  for a live demo. If you want a "real" LLM in the loop, you can optionally wire `OPENAI_API_KEY`
  in `backend/.env` and extend `chatService.js` to call an LLM for the final reply text, while
  still using the same real weather data. Mention this design choice in your reflection.
- **Multilingual support**: implemented via `frontend/translations.js` (English/Hindi/Tamil UI).
  Add more languages by adding another key to that file.
- **Deployment**: the frontend is plain static files, so you can also deploy backend separately
  (Render/Railway) and frontend on Netlify/Vercel by pointing `API_BASE` in `app.js` to your
  backend URL. As shipped, one Express server serves both, which also works fine on Render/Railway.
- **GitHub**: `git init`, commit this folder, then push and use branches/PRs as required by the rubric.

## Folder structure
```
WeatherGPT/
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   ├── routes/weather.js
│   └── services/
│       ├── weatherService.js
│       ├── alertService.js
│       └── chatService.js
├── frontend/
│   ├── index.html
│   ├── style.css
│   ├── app.js
│   └── translations.js
└── README.md
```
