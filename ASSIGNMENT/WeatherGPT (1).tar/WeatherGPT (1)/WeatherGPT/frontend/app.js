const API_BASE = "/api";
let currentLang = "en";
let currentCity = "Chennai";
let historyChartInstance = null;

const WEATHER_ICONS = {
  0: "☀️", 1: "🌤️", 2: "⛅", 3: "☁️", 45: "🌫️", 48: "🌫️",
  51: "🌦️", 53: "🌦️", 55: "🌧️", 56: "🌧️", 57: "🌧️",
  61: "🌧️", 63: "🌧️", 65: "🌧️", 66: "🌨️", 67: "🌨️",
  71: "🌨️", 73: "🌨️", 75: "❄️", 77: "❄️",
  80: "🌦️", 81: "🌧️", 82: "⛈️", 85: "🌨️", 86: "❄️",
  95: "⛈️", 96: "⛈️", 99: "⛈️",
};
function iconFor(code) { return WEATHER_ICONS[code] || "🌡️"; }

// ---------- i18n ----------
function applyTranslations() {
  const t = TRANSLATIONS[currentLang];
  document.getElementById("appName").textContent = t.appName;
  document.getElementById("tagline").textContent = t.tagline;
  document.getElementById("navChat").textContent = "💬 " + t.navChat;
  document.getElementById("navDashboard").textContent = "📊 " + t.navDashboard;
  document.getElementById("navAlerts").textContent = "🚨 " + t.navAlerts;
  document.getElementById("navHistory").textContent = "📈 " + t.navHistory;
  document.getElementById("citySearch").placeholder = t.searchPlaceholder;
  document.getElementById("citySearchBtn").textContent = t.searchBtn;
  document.getElementById("chatInput").placeholder = t.chatPlaceholder;
  document.getElementById("chatSendBtn").textContent = t.sendBtn;
  document.getElementById("forecastTitle").textContent = t.sevenDayForecast;
  document.getElementById("lblFeels").textContent = t.feelsLike;
  document.getElementById("lblHumidity").textContent = t.humidity;
  document.getElementById("lblWind").textContent = t.wind;
  document.getElementById("lblPrecip").textContent = t.precipitation;
  document.getElementById("alertsTitle").textContent = t.activeAlerts;
  document.getElementById("historyTitle").textContent = t.historyTitle;
  document.getElementById("loadHistoryBtn").textContent = t.loadHistory;
}

// ---------- Tabs ----------
document.querySelectorAll(".nav-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
  });
});

// ---------- Backend health ----------
async function checkBackend() {
  const el = document.getElementById("connStatus");
  try {
    const res = await fetch(`${API_BASE}/health`);
    if (res.ok) {
      el.textContent = "● Backend connected";
      el.className = "status ok";
    } else throw new Error();
  } catch {
    el.textContent = "● Backend not reachable";
    el.className = "status err";
  }
}

// ---------- Chat ----------
function addMessage(text, sender) {
  const win = document.getElementById("chatWindow");
  const div = document.createElement("div");
  div.className = `msg ${sender}`;
  div.textContent = text;
  win.appendChild(div);
  win.scrollTop = win.scrollHeight;
}

async function sendChat() {
  const input = document.getElementById("chatInput");
  const message = input.value.trim();
  if (!message) return;
  addMessage(message, "user");
  input.value = "";

  try {
    const res = await fetch(`${API_BASE}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, defaultCity: currentCity }),
    });
    const data = await res.json();
    addMessage(data.reply, "bot");
    if (data.data && data.data.place) {
      currentCity = data.data.place.name;
      if (data.data.current) renderDashboard(data.data);
      if (data.data.alerts) renderAlerts(data.data.place, data.data.alerts);
    }
  } catch (err) {
    addMessage("Sorry, I couldn't reach the weather service. Please check the backend is running.", "bot");
  }
}
document.getElementById("chatSendBtn").addEventListener("click", sendChat);
document.getElementById("chatInput").addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendChat();
});

// ---------- Dashboard ----------
function renderDashboard(wx) {
  document.getElementById("placeTitle").textContent = `${wx.place.name}, ${wx.place.country}`;
  document.getElementById("placeSub").textContent = wx.place.admin1 || "";

  document.getElementById("currentCard").style.display = "flex";
  document.getElementById("curTemp").textContent = `${wx.current.temperature}°C`;
  document.getElementById("curDesc").textContent = `${iconFor(wx.current.weatherCode)} ${wx.current.description}`;
  document.getElementById("curFeels").textContent = `${wx.current.feelsLike}°C`;
  document.getElementById("curHumidity").textContent = `${wx.current.humidity}%`;
  document.getElementById("curWind").textContent = `${wx.current.windSpeed} km/h`;
  document.getElementById("curPrecip").textContent = `${wx.current.precipitation} mm`;

  const row = document.getElementById("forecastRow");
  row.innerHTML = "";
  wx.daily.forEach((d) => {
    const card = document.createElement("div");
    card.className = "forecast-card";
    card.innerHTML = `
      <div class="fc-date">${d.date}</div>
      <div class="fc-icon">${iconFor(d.weatherCode)}</div>
      <div class="fc-desc">${d.description}</div>
      <div class="fc-temps">${Math.round(d.tempMin)}° / ${Math.round(d.tempMax)}°</div>
    `;
    row.appendChild(card);
  });
}

function renderAlerts(place, alerts) {
  const list = document.getElementById("alertsList");
  list.innerHTML = "";
  alerts.forEach((a) => {
    const card = document.createElement("div");
    card.className = `alert-card ${a.severity}`;
    card.innerHTML = `<div class="alert-type">${a.type}</div><div class="alert-msg">${a.message}</div>`;
    list.appendChild(card);
  });
}

async function loadCity(city) {
  currentCity = city;
  try {
    const res = await fetch(`${API_BASE}/weather?city=${encodeURIComponent(city)}`);
    if (!res.ok) throw new Error((await res.json()).error);
    const wx = await res.json();
    renderDashboard(wx);

    const alertRes = await fetch(`${API_BASE}/alerts?city=${encodeURIComponent(city)}`);
    const alertData = await alertRes.json();
    renderAlerts(alertData.place, alertData.alerts);
  } catch (err) {
    alert("Could not load weather: " + err.message);
  }
}

document.getElementById("citySearchBtn").addEventListener("click", () => {
  const city = document.getElementById("citySearch").value.trim();
  if (city) loadCity(city);
});
document.getElementById("citySearch").addEventListener("keydown", (e) => {
  if (e.key === "Enter") document.getElementById("citySearchBtn").click();
});

// ---------- History chart ----------
async function loadHistory() {
  const end = new Date();
  const start = new Date();
  start.setDate(end.getDate() - 7);
  const fmt = (d) => d.toISOString().split("T")[0];

  try {
    const res = await fetch(
      `${API_BASE}/history?city=${encodeURIComponent(currentCity)}&start=${fmt(start)}&end=${fmt(end)}`
    );
    const data = await res.json();
    const labels = data.daily.map((d) => d.date);
    const maxTemps = data.daily.map((d) => d.tempMax);
    const minTemps = data.daily.map((d) => d.tempMin);
    const precip = data.daily.map((d) => d.precipitationSum);

    const ctx = document.getElementById("historyChart").getContext("2d");
    if (historyChartInstance) historyChartInstance.destroy();
    historyChartInstance = new Chart(ctx, {
      type: "line",
      data: {
        labels,
        datasets: [
          { label: "Max Temp (°C)", data: maxTemps, borderColor: "#4fb0ff", tension: 0.3 },
          { label: "Min Temp (°C)", data: minTemps, borderColor: "#7ee0c3", tension: 0.3 },
          { label: "Precipitation (mm)", data: precip, borderColor: "#ffb703", tension: 0.3, yAxisID: "y1" },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: { ticks: { color: "#eaf2ff" }, grid: { color: "rgba(255,255,255,0.06)" } },
          y1: { position: "right", ticks: { color: "#eaf2ff" }, grid: { display: false } },
          x: { ticks: { color: "#eaf2ff" }, grid: { color: "rgba(255,255,255,0.06)" } },
        },
        plugins: { legend: { labels: { color: "#eaf2ff" } } },
      },
    });
  } catch (err) {
    alert("Could not load history: " + err.message);
  }
}
document.getElementById("loadHistoryBtn").addEventListener("click", loadHistory);

// ---------- Language ----------
document.getElementById("langPicker").addEventListener("change", (e) => {
  currentLang = e.target.value;
  applyTranslations();
  const win = document.getElementById("chatWindow");
  win.innerHTML = "";
  addMessage(TRANSLATIONS[currentLang].welcomeMsg, "bot");
});

// ---------- Init ----------
window.addEventListener("DOMContentLoaded", () => {
  applyTranslations();
  addMessage(TRANSLATIONS[currentLang].welcomeMsg, "bot");
  checkBackend();
  loadCity(currentCity);
});
